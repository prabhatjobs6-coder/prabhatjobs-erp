# Staff-work expansion plan

| Workflow | This release | Next integration |
|---|---|---|
| Document OCR and missing fields | Local engine tested; live bridge required | ERP review UI, source bindings and real-data accuracy validation |
| Role-specific resumes | A4 renderer tested; live upload bridge required | Approved templates, source-linked work history review, staff PDF preview |
| Recurring scan | Persistent worker implemented, not deployed | Existing host or private Docker host; optional authenticated events |
| Telegram controls | Adapter and authorization tests included, transport untested | Dedicated bot token and staff numeric IDs |
| Missing-document follow-up | Planned | Draft required-document list; approved WhatsApp/email templates and send permissions |
| Passport/PCC expiry | Planned | Date-driven internal reminders and assigned ERP tasks; country rules verified separately |
| Staff task routing/daily report | Planned | Existing ERP task tools; owner-approved staff roles and digest recipients |
| Interview preparation | Planned | Candidate-specific factual English/Gujarati practice sheets |
| Vacancy matching | Planned | Match documented skills and availability; human recruitment decision |
| Interviews and travel tracking | Planned | Existing modules, explicit scheduling scope and staff escalation |
| Payments/refunds/visa outcome/selection | Not autonomous in this release | Separate approval-controlled workflows and verified events |
| WhatsApp candidate agent | Not implemented | Approved Business Platform integration; existing Maya rule: no rates, collect details and route to staff |
| Superfone call summaries | Not implemented | Reuse existing integration only after API access and scope are authorized |
| Google Drive ingestion | Not implemented | Read-only scoped Drive access, candidate identity matching, source hashes and links |

The biggest saving comes from avoiding repeated extraction: hash/version documents, skip unchanged
records, render PDFs locally, and use Claude for text interpretation rather than clicking every
webpage field. Deterministic business actions do not need a large reasoning-model call each time.

Neither the model nor the bot replaces employer/legal decisions. No automatic hiring/rejection
score or inferred sensitive-characteristic assessment is included.
