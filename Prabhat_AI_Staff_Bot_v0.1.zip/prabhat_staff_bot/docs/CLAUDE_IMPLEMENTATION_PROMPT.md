# Paste into Claude Code in the ACTUAL Prabhatjobs source repository

You are implementing Prabhat Staff Bot for Prabhat Professional Consultancy Services Pvt. Ltd.
Read the repository's AGENTS.md, README, existing auth, candidate models, document storage,
audit, background jobs and deployment instructions first. Do not invent routes or schemas.

The companion package contains a tested Python OCR/extraction/proposal/PDF worker. It is not
yet connected to production. Implement `docs/ERP_BRIDGE_CONTRACT.md` against this ERP's actual
services. Preserve existing design and features. Reuse an existing private worker/server if
suitable to minimize recurring cost. Do not build a paid orchestration dependency by default.

User objective:
- Read all existing candidate source documents; fill ONLY the user-configured empty fields.
- Preserve existing values and skills/trades. Never delete or silently replace data.
- Create an A4 resume for occupations selected by owner/staff. Preserve factual identity,
  education, employers, role, dates, duties and supported skills. No invented experience.
- Upload new resume variants to the correct profile, idempotently, with full provenance.
- Continue across candidates, retry bounded transient failures and report unresolved records.

Observed connector supports candidate read/search/update and document metadata listing, but
no downloadable document bytes, resume upload or atomic compare-and-set endpoint was exposed.
Read-only dashboard observation on 14 October 2026: 4,794 candidates and 42 active vacancies.
These are observations, not database schema definitions or hard-coded expectations.

Implementation tasks:
1. Map all actual candidate field aliases. If two populated aliases conflict, queue review.
2. Implement the bridge with dedicated service-account scopes, existing category permissions,
   complete pagination, expiring credentials where supported, and audited actor attribution.
3. Missing-field PATCH must use a real transaction/CAS; maintain existing duplicate guards.
4. Resume POST must be append-only, versioned, protected, role-specific and idempotent. Avoid
   regenerating because the bot's own output updated a general `updatedAt` timestamp.
5. Create an authenticated staff review screen in the existing ERP: original document viewer,
   field before/proposed value, source quote/page, per-field apply, ignore and conflict reason;
   PDF preview plus approve upload. Server-side permissions govern every action.
6. Persist review decisions and corrected evidence; do not allow LLM output to self-approve.
7. Expose document-added and skill-selection-change events if the existing app supports them.
   Keep polling as a fallback; events need auth, dedupe and a durable queue. The companion
   worker currently polls; do not claim webhooks are already implemented.
8. Put secrets in deployment secrets/environment. Claude interprets source text; deterministic
   code controls permissions, writes, matching, PDF layout and budgets.
9. Add meaningful tests for race conditions, identity mismatch, authorization, duplicate
   events/uploads, malformed/oversized documents, non-empty field protection and resume provenance.
10. Run the package's demo tests. Then validate staging using actual document types and a small
    representative owner-approved sample. Report real OCR/field accuracy and unresolved cases.
11. Prepare a reviewed field policy and rollback/backup steps. Deploy only through the
    repository's established deployment process. Report exactly what is and is not activated.

Initial auto-fields and resume auto-upload remain disabled until the owner selects them.
Later autonomous permissions can be saved as policy, without repeatedly asking for already
authorized routine fills. Employment selection/rejection, finance, deletion and external
messages remain separate explicitly authorized workflows.

Do not create or forge experience letters, signatures, stamps, employers or years. A selected
trade is a target role, not evidence of previous employment. Support English CV output and
reviewed Gujarati/Hindi source interpretation. Keep original supporting documents unchanged.
