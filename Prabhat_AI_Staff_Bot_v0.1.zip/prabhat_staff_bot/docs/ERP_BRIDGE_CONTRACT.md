# Proposed ERP bridge contract v1

This is a **new required backend integration**, not a description of discovered production
routes. Implement inside the existing authenticated prabhatjobs backend after inspecting its
actual code. The bot has no direct database access. Base URL is configured by the deployer.

All routes require a dedicated bearer token, role-scoped permissions, HTTPS, request limits,
and the existing ERP audit rules. Never reuse browser cookies or place administrative keys
in a frontend. Document binaries must be streamed through this authenticated bridge; the
worker will not follow redirects or forward ERP credentials to a storage domain.

## Normalized candidate schema

```json
{
  "id": "PCS-EXAMPLE",
  "revision": "opaque-profile-and-source-version",
  "fields": {
    "name": "Candidate Name", "dob": "1990-01-01", "passport_no": "EXAMPLE123",
    "passport_expiry": "2030-01-01", "phone": "", "email": "", "address": "",
    "city": "", "state": "", "education": "", "languages": []
  },
  "skills": ["Furniture Carpenter"],
  "resume_roles": ["Furniture Carpenter"],
  "verified_skills": [],
  "work_history": []
}
```

Empty means null, empty/whitespace string or empty array. Numeric zero and false are NOT
empty. Do not collapse populated aliases into empty canonical fields. The observed ERP has
aliases such as `passportNo` / `passportNumber`, `currentAddress` / `permanentAddress`,
`experience` / `totalExperience`, and `trade` / `trades` / `skills`; inspect real storage and
existing service semantics before mapping. If aliases disagree, expose a conflict for review.
Do not concatenate differing addresses. Do not infer DOB/expiry from age or issue date.

`revision` changes whenever source profile facts, selected roles, document content/version,
verified employment or verified skills change. Adding bot-generated output alone MUST NOT
change this content revision. This prevents resume-upload loops. Support both immutable
canonical candidate ID and PCS code, with a single resolved identity for all operations.

## Endpoints

| Method | Route relative to bridge base | Required response/behavior |
|---|---|---|
| GET | `/capabilities` | `{"contract_version":1,"features":["candidate_read","documents_download","missing_fields_cas","resume_append_idempotent"]}` |
| GET | `/candidates?cursor=&limit=100` | `{"items":[candidate],"next_cursor":null}`; stable keyset pagination over all permitted candidates |
| GET | `/candidates/{id}` | One normalized candidate |
| GET | `/candidates/{id}/documents` | `{"items":[document]}`; complete source list, excluding bot output; reject instead of truncating |
| GET | `/candidates/{id}/documents/{doc_id}/content` | Original bytes; verify document belongs to candidate and caller has category access |
| PATCH | `/candidates/{id}/missing-fields` | Atomically check version, emptiness and allowlist, then fill fields; return candidate |
| POST | `/candidates/{id}/resumes` | Append one resume variant; return `{"id":"document-id","sha256":"..."}` |

Document metadata:

```json
{
  "id": "document-id", "filename": "passport.pdf", "version": "1",
  "sha256": "actual-64-character-SHA256-if-available",
  "binding_verified": false, "origin": "staff_upload"
}
```

`binding_verified=true` only after an authorized person has verified that this document
belongs to this candidate. Never set it simply because a file was uploaded into that profile.
Every document must have a stable version which changes when bytes change. Sha256 is optional
but recommended. Do not include placeholder hashes. Return byte size/MIME if useful.

## Missing-field write

Headers: `If-Match: <revision>` and `Idempotency-Key: <key>`.

Body: `{"fields":{"city":"Porbandar"},"evidence":{"city":[{"doc_id":"...","page":1,"quote":"...","sha256":"..."}]}}`.

Inside one database transaction:

1. Recheck authorization and resolve the candidate.
2. If this idempotency key was already successfully committed for the same request, replay
   the saved response before revision checks. Different payload with the same key returns 409.
3. Lock/check the content revision and all document versions/hashes. On mismatch, return
   409/412. Do not accept a successful no-op response for a rejected update.
4. Validate every field against a server-side allowlist and type rules. For this version,
   reject skills/trades/status/stage/ratings/fees/bank/selection/visa decision writes.
5. Verify every target and its aliases are still empty. A non-empty target rejects the whole
   transaction. Enforce existing phone/passport duplicate guards.
6. Apply exactly the submitted fields; write before/after/source/actor/time audit entries.
7. Commit a new revision and idempotency result atomically. Return normalized candidate.

This requires compare-and-set support beyond the current exposed `update_candidate` tool.
A client-side read followed by a generic update is not a substitute: staff may edit between them.

## Resume upload

Headers: `If-Match` and `Idempotency-Key` as above.

Body: filename, `mime_type=application/pdf`, role, base64 content, SHA256, and source refs
`[{"id":"document-id","sha256":"..."}]`. Maximum decoded size 10 MB. Validate actual PDF
and MIME, safe filename, digest, role selected by staff, candidate ownership and source version.
Use existing file scanning/storage services. Mark `origin=prabhat_staff_bot`, role, template
version and source fingerprint. Replay idempotent results without making duplicate files.
Never replace an original CV or delete supporting documents. Use the existing secure document
viewer and category visibility. A stored file without a candidate association is a failure.

## Permission and failure cases

Return 401/403 for access denial, 404 for inaccessible/unknown resources, 409/412 for conflict,
413 for oversized input, 422 for validation, 429 for throttling. Preserve permissions on sensitive
document categories. Test cross-candidate document IDs, expired tokens, concurrent staff edits,
duplicate phone/passport, network loss after a committed write, repeated upload keys and role changes.

No payment, messaging, interview selection or deletion permission is needed for this module.
