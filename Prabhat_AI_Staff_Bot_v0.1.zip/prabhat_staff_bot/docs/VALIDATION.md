# Validation record - 14 October 2026

Local runtime: Python 3.12.14, pypdf 6.10.0, ReportLab 4.4.9, Pillow 12.3.0,
system Tesseract with English data, and Poppler.

`python3 -m unittest discover -s tests -v`: **19 tests passed**.

Tested behavior:
- Fill only approved empty fields; preserve populated values and existing skills.
- Preview mode does not mutate the simulated ERP; explicit field scope is enforced.
- Automatic mode writes only the owner-configured auto fields.
- Existing-profile conflicts, ambiguous dates, mixed passports and unsupported AI evidence.
- Missing-passport proposals require an explicitly staff-bound source bundle.
- Concurrent profile change invalidates a proposal before mutation.
- Resume generation produces one A4 page, omits passport unless enabled, and only accepts
  staff-selected roles. Repeated approvals/regeneration create one logical uploaded variant.
- Embedded PDF text extraction and actual Tesseract OCR of a generated scanned image.
- Persistent extraction cache and repeated scan deduplication.
- Retry after an HTTP 429 and a new process/Engine instance using the same durable state.
- Budget reservations prevent a request beyond the configured cap.
- Telegram command access allows only configured user IDs in private chats.

The synthetic demo produced two review jobs and one PDF. The PDF was rendered and visually
inspected for legibility, clipping, overlap and layout. `examples/sample_resume.pdf` is that
demonstration output; it is visibly labeled synthetic and contains no real candidate data.

Not tested or activated here:
- Authenticated live Claude API calls, model access and actual token billing.
- Real candidate document OCR accuracy, Gujarati/Hindi OCR or handwriting.
- Actual ERP bridge endpoints, upload storage, server-side CAS, role enforcement or live writes.
- Docker image build/start, production hosting, Telegram network transport or 24/7 runtime.
- Task routing, WhatsApp, Superfone, visa workflows, payments, Drive ingestion and hiring decisions.

These are deployment/integration requirements, not functionality being represented as live.
No production candidate record or document was modified during this task.
