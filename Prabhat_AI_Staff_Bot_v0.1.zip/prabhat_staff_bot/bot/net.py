import json
import urllib.error
import urllib.request

class RemoteError(RuntimeError):
    def __init__(self, status):
        self.status = status
        super().__init__(f'Remote request failed (HTTP {status}); no credentials or response body logged')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None

def request(url, method='GET', body=None, headers=None, limit=25*1024*1024, timeout=60, binary=False):
    h = dict(headers or {})
    raw = None
    if body is not None:
        raw = json.dumps(body, ensure_ascii=False).encode()
        h['Content-Type'] = 'application/json'
    req = urllib.request.Request(url, data=raw, method=method, headers=h)
    try:
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=timeout) as r:
            data = r.read(limit+1)
            if len(data) > limit:
                raise ValueError('Response exceeds size limit')
            return data if binary else json.loads(data or b'{}')
    except urllib.error.HTTPError as e:
        raise RemoteError(e.code) from None
    except urllib.error.URLError:
        raise RemoteError(0) from None
