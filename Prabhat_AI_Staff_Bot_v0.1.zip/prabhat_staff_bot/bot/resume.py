from html import escape
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.pdfgen.canvas import Canvas
from pypdf import PdfReader

class ResumeNeedsReview(RuntimeError):
    pass

def render_resume(candidate, plan, role, output, include_passport=False):
    fields = dict(candidate['fields'])
    for k, v in plan['proposals'].items():
        fields[k] = v['value']
    if not fields.get('name'):
        raise ResumeNeedsReview('A verified name is required')
    # English CV renderer: retain Unicode values in the ledger, require transliteration review.
    def text(value):
        s = str(value)
        if any(ord(ch)>591 for ch in s):
            raise ResumeNeedsReview('Non-Latin resume content needs staff-approved English transliteration')
        return escape(s)
    font_path = Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    if font_path.exists():
        if 'BotSans' not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont('BotSans',str(font_path)))
            pdfmetrics.registerFont(TTFont('BotSansBold',str(font_path.with_name('DejaVuSans-Bold.ttf'))))
        regular, bold = 'BotSans', 'BotSansBold'
    else:
        regular, bold = 'Helvetica', 'Helvetica-Bold'
    styles = {
       'name': ParagraphStyle('name',fontName=bold,fontSize=21,leading=26,textColor=colors.HexColor('#173957')),
       'role': ParagraphStyle('role',fontName=regular,fontSize=13,leading=18,textColor=colors.HexColor('#416B87')),
       'body': ParagraphStyle('body',fontName=regular,fontSize=10.5,leading=15,spaceAfter=4),
       'heading': ParagraphStyle('heading',fontName=bold,fontSize=11,leading=17,textColor=colors.HexColor('#173957'),spaceBefore=13,spaceAfter=6)
    }
    p = lambda s, typ='body': Paragraph(s,styles[typ])
    story = [p(text(fields['name']),'name'),Spacer(1,5),p('Target role: '+text(role),'role'),Spacer(1,13)]
    contact = [fields.get(x) for x in ['phone','email','city','state'] if fields.get(x)]
    if contact:
        story += [p(' | '.join(text(x) for x in contact))]
    personal = []
    for key, label in [('dob','Date of birth'),('address','Address')]:
        if fields.get(key): personal.append([p(label),p(text(fields[key]))])
    if include_passport:
        for key,label in [('passport_no','Passport number'),('passport_expiry','Passport expiry')]:
            if fields.get(key): personal.append([p(label),p(text(fields[key]))])
    if personal:
        story.append(p('PERSONAL DETAILS','heading'))
        t = Table(personal,colWidths=[118,393],hAlign='LEFT')
        t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
        story.append(t)
    histories = [h for h in candidate.get('work_history',[]) if h.get('verified') is True]
    histories += [h['value'] for h in plan['work_history']]
    if histories:
        story.append(p('WORK EXPERIENCE','heading'))
        seen = set()
        for h in histories:
            identity = (h.get('employer'),h.get('role'),h.get('period'))
            if identity in seen: continue
            seen.add(identity)
            block = [p(text(h['role'])+' | '+text(h['employer'])),p(text(h['period']))]
            block.extend(p('- '+text(d)) for d in h.get('duties',[]))
            story.append(KeepTogether(block))
    if fields.get('education'):
        story.extend([p('EDUCATION','heading'),p(text(fields['education']))])
    # Staff-selected job interests alone do not establish mastery of occupational skills.
    verified_skills = candidate.get('verified_skills',[])
    if verified_skills:
        story.extend([p('CORE SKILLS','heading'),p(', '.join(text(s) for s in verified_skills))])
    if fields.get('languages'):
        story.extend([p('LANGUAGES','heading'),p(', '.join(text(s) for s in fields['languages']))])
    output = Path(output)
    output.parent.mkdir(parents=True,exist_ok=True)
    def page(c,doc):
        c.setStrokeColor(colors.HexColor('#D6E3ED'))
        c.line(42,792,553,792)
        c.setFont(regular,8)
        c.setFillColor(colors.HexColor('#617485'))
        if candidate.get('demo'):
            c.drawString(42,25,'SYNTHETIC DEMONSTRATION - NOT A REAL CANDIDATE')
    doc = SimpleDocTemplate(str(output),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=61,bottomMargin=43,
                            title=fields['name']+' - '+role, author='Prabhat Professional Consultancy Services Pvt. Ltd.')
    def stable_canvas(*args, **kwargs):
        kwargs['invariant']=1
        return Canvas(*args, **kwargs)
    doc.build(story,onFirstPage=page,onLaterPages=page,canvasmaker=stable_canvas)
    if len(PdfReader(output).pages)!=1:
        output.unlink(missing_ok=True)
        raise ResumeNeedsReview('Content does not fit one legible A4 page; no content was deleted')
    return output
