import hashlib
import json
import time
from pathlib import Path
from .erp import adapter, empty, StaleProfile
from .extract import extract_document, PARSER_VERSION
from .net import RemoteError
from .policy import plan
from .resume import render_resume
from .state import State, digest

class Engine:
    def __init__(self, config, erp=None):
        self.config = config
        self.state = State(config.data)
        self.erp = erp or adapter(config)

    def check(self):
        caps = self.erp.capabilities()
        needed = {'candidate_read','documents_download','missing_fields_cas','resume_append_idempotent'}
        if caps.get('contract_version')!=1 or not needed.issubset(set(caps.get('features',[]))):
            raise RuntimeError('ERP bridge capabilities are incomplete; live writes remain blocked')
        return caps

    def fingerprint(self, c, docs):
        # Content version excludes bot-generated resumes, preventing regeneration loops.
        docs=[d for d in docs if d.get('origin')!='prabhat_staff_bot']
        return digest([c['id'],c['revision'],[(d['id'],d['version'],d.get('sha256'),d.get('binding_verified',False)) for d in docs],
                       c.get('resume_roles',[]), self.config.policy, PARSER_VERSION,
                       self.config.model, bool(self.config.api_key), self.config.ocr_lang])

    def enqueue_candidate(self, c, docs, resumes=False, role=None, force=False):
        key = self.fingerprint(c, docs)
        if force:
            key += str(time.time_ns())
        ids=[]
        if role is None and any(empty(c['fields'].get(f)) for f in self.config.policy['allowed_fields']):
            ids.append(self.state.enqueue([key,'profile'],c['id'],'profile'))
        roles = [role] if role else (c.get('resume_roles',[]) if resumes else [])
        for target in roles:
            if target not in c.get('resume_roles',[]):
                raise ValueError('Select this resume role in the candidate profile first')
            ids.append(self.state.enqueue([key,'resume',target],c['id'],'resume',target))
        return ids

    def scan(self, resumes=False):
        self.check()
        count, jobs, failures = 0, 0, 0
        for c in self.erp.candidates():
            count+=1
            try:
                docs=self.erp.documents(c['id'])
                if docs:
                    jobs+=len(self.enqueue_candidate(c,docs,resumes))
            except Exception as e:
                failures+=1
                self.state.event('', 'scan_failure', {'candidate_id':c.get('id'),'type':type(e).__name__})
        return {'candidates_seen':count,'job_ids_seen_or_queued':jobs,'scan_failures':failures}

    def process(self, job):
        c=self.erp.get(job['candidate'])
        docs=self.erp.documents(c['id'])
        # Never feed previous bot output back in as independent evidence.
        docs=[d for d in docs if d.get('origin')!='prabhat_staff_bot']
        if not docs:
            raise ValueError('No source documents')
        if len(docs)>self.config.policy['max_documents_per_candidate']:
            raise ValueError('Document-count limit exceeded')
        extracted=[]
        for d in docs:
            result=extract_document(self.erp.download(c['id'],d),d,self.config,self.state)
            extracted.append({**result,'binding_verified':d.get('binding_verified',False)})
        proposal=plan(c,extracted,self.config.policy)
        payload={'candidate':c, 'plan':proposal, 'source_fingerprint':self.fingerprint(c,docs)}
        if job['operation']=='resume':
            if job['role'] not in c.get('resume_roles',[]):
                raise ValueError('Resume role removed from candidate profile')
            if not proposal['identity_ok'] or proposal['issues']:
                self.state.save(job['id'],'review',payload)
                return
            pdf=self.config.data/'resumes'/(job['id']+'.pdf')
            render_resume(c,proposal,job['role'],pdf,self.config.policy['include_passport_in_resume'])
            payload['pdf']=str(pdf)
            payload['pdf_sha256']=hashlib.sha256(pdf.read_bytes()).hexdigest()
        self.state.save(job['id'],'review',payload)
        self.state.event(job['id'],'proposal_created',{'operation':job['operation'],'plan':proposal})
        if self.config.writes and not proposal['issues'] and proposal['identity_ok']:
            if job['operation']=='profile':
                fields=[k for k,v in proposal['proposals'].items() if v['auto']]
                if fields:
                    self.apply(job['id'],fields,automatic=True)
                elif not proposal['proposals']:
                    self.state.save(job['id'],'no_changes')
            elif self.config.policy['auto_upload_resumes']:
                self.apply(job['id'],[],automatic=True)
        elif job['operation']=='profile' and not proposal['proposals'] and not proposal['issues']:
            self.state.save(job['id'],'no_changes')

    def run(self):
        self.check()
        with self.state.worker_lock():
            # A prior crash may have left a job in progress; mutations have durable idempotency keys.
            jobs=self.state.jobs()
            for j in jobs:
                if j['state'] not in {'queued','processing'} or j['next_at']>time.time():
                    continue
                self.state.save(j['id'],'processing',attempt=True)
                try:
                    self.process(j)
                except Exception as e:
                    attempts=j['attempts']+1
                    transient=isinstance(e,RemoteError) and (e.status==0 or e.status==429 or e.status>=500)
                    retry=transient and attempts<self.config.policy['max_attempts']
                    # Never log provider bodies, tokens, or source text in error output.
                    self.state.save(j['id'],'queued' if retry else 'error',error=type(e).__name__+': '+str(e)[:180],
                                    retry_after=30*(2**attempts) if retry else 0)
            return self.state.summary()

    def apply(self, job_id, fields, automatic=False):
        if not self.config.writes:
            raise RuntimeError('ENABLE_WRITES=false. Review is available; writing is disabled.')
        job=self.state.get(job_id)
        if job['state']=='completed':
            return {'already_completed':True}
        if job['state']!='review' or not job['payload']:
            raise ValueError('Job is not ready for review')
        p=job['payload']['plan']
        if not p['identity_ok'] or any(x['field']=='identity_conflict' for x in p['issues']):
            raise ValueError('Resolve identity in ERP/documents, then rescan; approval cannot bypass identity mismatch')
        current=self.erp.get(job['candidate'])
        docs=self.erp.documents(current['id'])
        docs=[d for d in docs if d.get('origin')!='prabhat_staff_bot']
        if self.fingerprint(current,docs)!=job['payload']['source_fingerprint']:
            self.state.save(job_id,'stale')
            raise StaleProfile('Source or profile changed; rescan before writing')
        if job['operation']=='resume':
            if p['issues'] or not job['payload'].get('pdf'):
                raise ValueError('Resolve source conflicts, then regenerate the resume')
            pdf=Path(job['payload']['pdf'])
            if hashlib.sha256(pdf.read_bytes()).hexdigest()!=job['payload']['pdf_sha256']:
                raise ValueError('Resume file changed after review')
            upload_key=digest([job['payload']['source_fingerprint'],job['role'],'resume-template-v1'])
            result=self.erp.upload(current['id'],current['revision'],pdf,job['role'],upload_key,p['documents'])
            if not result.get('id'):
                raise RuntimeError('Upload did not return a document ID')
            self.state.event(job_id,'resume_uploaded',{'document_id':result['id'],'sha256':job['payload']['pdf_sha256']})
            self.state.save(job_id,'completed')
            return result
        if not fields or len(fields)!=len(set(fields)):
            raise ValueError('Specify the exact non-duplicate fields to approve')
        values, sources={},{}
        for f in fields:
            if f not in p['proposals'] or f not in self.config.policy['allowed_fields']:
                raise ValueError('Field has no supported proposal')
            if automatic and not p['proposals'][f]['auto']:
                raise ValueError('Field requires review')
            if not empty(current['fields'].get(f)):
                raise StaleProfile('Existing field is now populated')
            values[f]=p['proposals'][f]['value']
            sources[f]=p['proposals'][f]['evidence']
        # Exact subset has its own idempotency key. Server must enforce CAS and missing-only atomically.
        write_key=digest([job_id,values])
        self.state.event(job_id,'write_intent',{'before':{f:current['fields'].get(f) for f in values},'after':values,'evidence':sources,'idempotency_key':write_key})
        result=self.erp.patch(current['id'],current['revision'],values,write_key,sources)
        verify=self.erp.get(current['id'])
        if any(verify['fields'].get(k)!=v for k,v in values.items()):
            self.state.save(job_id,'verify_failed')
            raise RuntimeError('Post-write values differ; manual review required')
        self.state.event(job_id,'write_verified',{'fields':list(values),'revision':verify['revision']})
        self.state.save(job_id,'completed')
        # Unapproved missing values are handled by a new revision-specific proposal on the next scan.
        return {'updated_fields':list(values)}

    def review_file(self, job_id):
        import html
        job=self.state.get(job_id)
        if not job.get('payload'):
            raise ValueError('No proposal available')
        folder=self.config.data/'reviews'
        folder.mkdir(exist_ok=True)
        target=folder/(job_id+'.html')
        payload=html.escape(json.dumps(job['payload']['plan'],indent=2,ensure_ascii=False))
        pdf=job['payload'].get('pdf')
        link='<a href="../resumes/'+html.escape(Path(pdf).name)+'">Open PDF draft</a>' if pdf else ''
        target.write_text('<!doctype html><meta charset="utf-8"><title>Prabhat review</title>'
            '<style>body{font:15px system-ui;max-width:1000px;margin:40px auto;color:#173957}pre{white-space:pre-wrap;background:#f1f6fa;padding:24px}</style>'
            '<h1>Candidate update review</h1><p>Check each source quote against the original document before approval.</p>'+link+'<pre>'+payload+'</pre>')
        return target
