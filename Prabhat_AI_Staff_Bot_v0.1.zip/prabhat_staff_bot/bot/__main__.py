import argparse
import json
import os
import time
from .config import Config
from .engine import Engine

def main():
    parser=argparse.ArgumentParser(description='Prabhat Staff Bot - private document and resume worker')
    sub=parser.add_subparsers(dest='cmd',required=True)
    sub.add_parser('check')
    sub.add_parser('demo')
    scan=sub.add_parser('scan'); scan.add_argument('--resumes',action='store_true')
    run=sub.add_parser('run'); run.add_argument('--watch',action='store_true'); run.add_argument('--resumes',action='store_true')
    sub.add_parser('status'); sub.add_parser('list')
    review=sub.add_parser('review'); review.add_argument('job_id')
    approve=sub.add_parser('approve'); approve.add_argument('job_id'); approve.add_argument('--fields',default='')
    res=sub.add_parser('resume'); res.add_argument('candidate_id'); res.add_argument('role'); res.add_argument('--force',action='store_true')
    sub.add_parser('telegram')
    args=parser.parse_args()
    os.umask(0o077)
    config=Config.load()
    if args.cmd=='demo':
        config.mode='demo'; config.writes=False; config.api_key=''
    engine=Engine(config)
    if args.cmd=='check':
        result={'mode':config.mode,'writes_enabled':config.writes,'claude_configured':bool(config.api_key),'bridge':engine.check()}
    elif args.cmd=='demo':
        engine.scan(resumes=True); engine.run()
        result=engine.state.summary()
        result['review_files']=[str(engine.review_file(j['id'])) for j in engine.state.jobs('review')]
    elif args.cmd=='scan': result=engine.scan(args.resumes)
    elif args.cmd=='run':
        if args.watch:
            while True:
                try:
                    if engine.state.kv('paused')!='true':
                        engine.scan(args.resumes); print(json.dumps(engine.run()),flush=True)
                except Exception as e:
                    print(json.dumps({'error_type':type(e).__name__}),flush=True)
                # Service loop; not run from this chat. SIGTERM/CTRL-C stops it.
                time.sleep(config.policy['scan_interval_seconds'])
        else: result=engine.run()
    elif args.cmd=='status': result=engine.state.summary()
    elif args.cmd=='list':
        result=[{k:j[k] for k in ['id','candidate','operation','role','state','error']} for j in engine.state.jobs()]
    elif args.cmd=='review': result={'review_file':str(engine.review_file(args.job_id))}
    elif args.cmd=='approve':
        with engine.state.worker_lock():
            result=engine.apply(args.job_id,[f.strip() for f in args.fields.split(',') if f.strip()])
    elif args.cmd=='resume':
        c=engine.erp.get(args.candidate_id)
        result={'jobs':engine.enqueue_candidate(c,engine.erp.documents(c['id']),role=args.role,force=args.force)}
    elif args.cmd=='telegram':
        from .telegram import serve
        serve(engine); return
    print(json.dumps(result,indent=2,ensure_ascii=False))

if __name__=='__main__':
    main()
