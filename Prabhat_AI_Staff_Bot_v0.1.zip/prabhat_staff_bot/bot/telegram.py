"""Optional command interface. No candidate documents or secrets are sent to Telegram."""
import json
import os
import time
from .net import request

def authorized(message, users):
    return message.get('chat',{}).get('type')=='private' and str(message.get('from',{}).get('id')) in users

def serve(engine):
    token=os.getenv('TELEGRAM_BOT_TOKEN','')
    users={x.strip() for x in os.getenv('TELEGRAM_ALLOWED_USER_IDS','').split(',') if x.strip()}
    if not token or not users:
        raise ValueError('Set Telegram bot token and numeric allowed user IDs in .env')
    base='https://api.telegram.org/bot'+token
    def call(method, body): return request(base+'/'+method,'POST',body,timeout=40)
    if call('getWebhookInfo',{}).get('result',{}).get('url'):
        raise RuntimeError('Existing Telegram webhook detected; use a dedicated bot for this polling service')
    while True:
        try:
            offset=int(engine.state.kv('telegram_offset') or '0')
            result=call('getUpdates',{'offset':offset,'timeout':25,'allowed_updates':['message']})
            for update in result.get('result',[]):
                msg=update.get('message',{})
                if authorized(msg,users):
                    words=msg.get('text','').split(maxsplit=2)
                    cmd=words[0].split('@')[0] if words else ''
                    if cmd=='/status': reply=json.dumps(engine.state.summary())
                    elif cmd=='/scan': reply=json.dumps(engine.scan(resumes=True))
                    elif cmd=='/pause': engine.state.kv('paused','true'); reply='Next scheduled scan paused. An already-running job may finish.'
                    elif cmd=='/resume_jobs': engine.state.kv('paused','false'); reply='Scheduled scans enabled.'
                    elif cmd=='/resume' and len(words)==3:
                        c=engine.erp.get(words[1])
                        ids=engine.enqueue_candidate(c,engine.erp.documents(c['id']),role=words[2])
                        reply='Queued resume job: '+', '.join(ids)
                    elif cmd=='/pending':
                        reply='\n'.join(j['id']+' '+j['operation'] for j in engine.state.jobs('review')[:20]) or 'No pending reviews.'
                    else:
                        reply='/status /scan /pending /resume PCS-CODE Target Role /pause /resume_jobs\nReview and approve changes on the private worker host.'
                    call('sendMessage',{'chat_id':msg['chat']['id'],'text':reply[:3500]})
                engine.state.kv('telegram_offset',update['update_id']+1)
        except KeyboardInterrupt:
            return
        except Exception:
            # Token appears in Telegram URLs: never echo exception text or a traceback.
            time.sleep(5)
