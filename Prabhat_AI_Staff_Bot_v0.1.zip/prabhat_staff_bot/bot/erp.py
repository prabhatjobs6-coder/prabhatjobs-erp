import base64
import copy
import hashlib
import json
import os
import shutil
from pathlib import Path
from urllib.parse import quote, urlencode, urlsplit
from .config import ROOT
from .net import request

class StaleProfile(RuntimeError):
    pass

def empty(value):
    # False and numeric zero are real existing values.
    return value is None or value == '' or (isinstance(value, str) and not value.strip()) or value == []

class DemoERP:
    def __init__(self, config):
        self.config = config
        self.path = config.data / 'demo-candidates.json'
        if not self.path.exists():
            shutil.copyfile(ROOT / 'examples/candidates.json', self.path)

    def capabilities(self):
        return {'contract_version': 1, 'features': ['candidate_read', 'documents_download', 'missing_fields_cas', 'resume_append_idempotent']}

    def _read(self):
        return json.loads(self.path.read_text())

    def _write(self, items):
        temp = self.path.with_suffix('.tmp')
        temp.write_text(json.dumps(items, indent=2))
        os.replace(temp, self.path)

    def candidates(self):
        yield from self._read()

    def get(self, cid):
        return copy.deepcopy(next(c for c in self._read() if c['id'] == cid))

    def documents(self, cid):
        return self.get(cid)['documents']

    def download(self, cid, doc):
        p = (ROOT / 'examples' / doc['filename']).resolve()
        if not p.is_relative_to(ROOT / 'examples'):
            raise ValueError('Invalid example path')
        return p.read_bytes()

    def patch(self, cid, revision, fields, key, evidence):
        items = self._read()
        c = next(c for c in items if c['id'] == cid)
        if key in c.get('applied_keys', []):
            return c
        if str(c['revision']) != str(revision):
            raise StaleProfile('Candidate changed; rebuild the proposal')
        if any(not empty(c['fields'].get(f)) for f in fields):
            raise StaleProfile('A target field is no longer empty')
        c['fields'].update(fields)
        c.setdefault('applied_keys', []).append(key)
        c['revision'] = str(int(c['revision'])+1)
        self._write(items)
        return c

    def upload(self, cid, revision, pdf, role, key, source_refs):
        items = self._read()
        c = next(c for c in items if c['id'] == cid)
        existing = next((r for r in c.get('resumes', []) if r['key'] == key), None)
        if existing:
            return existing
        if str(c['revision']) != str(revision):
            raise StaleProfile('Profile changed since PDF creation')
        dst = self.config.data / 'demo-uploads' / (key + '.pdf')
        dst.parent.mkdir(exist_ok=True)
        shutil.copyfile(pdf, dst)
        item = {'id': key, 'key': key, 'role': role, 'filename': dst.name, 'sha256': hashlib.sha256(dst.read_bytes()).hexdigest()}
        c.setdefault('resumes', []).append(item)
        # Uploads must not alter the revision used to identify profile/content changes.
        self._write(items)
        return item

class BridgeERP:
    """Client for the NEW contract in docs/ERP_BRIDGE_CONTRACT.md, not an existing ERP route."""
    def __init__(self, config):
        self.config = config
        u = urlsplit(config.bridge_url)
        if u.scheme != 'https' or not u.netloc or u.username or u.query or u.fragment:
            raise ValueError('ERP_BRIDGE_URL must be a configured HTTPS bridge base URL')
        if not config.bridge_token:
            raise ValueError('ERP_BRIDGE_TOKEN is required')
        self.base = config.bridge_url

    def _call(self, route, method='GET', body=None, extra=None, binary=False):
        h = {'Authorization': 'Bearer '+self.config.bridge_token, **(extra or {})}
        return request(self.base+route, method, body, h, binary=binary,
                       limit=self.config.policy['max_document_mb']*1024*1024)

    def capabilities(self):
        return self._call('/capabilities')

    def candidates(self):
        cursor = ''
        seen = set()
        while True:
            result = self._call('/candidates?'+urlencode({'cursor': cursor, 'limit': 100}))
            yield from result['items']
            cursor = result.get('next_cursor')
            if not cursor:
                break
            if cursor in seen:
                raise RuntimeError('Repeated pagination cursor')
            seen.add(cursor)

    def get(self, cid):
        return self._call('/candidates/'+quote(cid, safe=''))

    def documents(self, cid):
        result = self._call('/candidates/'+quote(cid,safe='')+'/documents')
        return result['items']  # Bridge must return complete list, or reject; see contract.

    def download(self, cid, doc):
        return self._call('/candidates/'+quote(cid,safe='')+'/documents/'+quote(doc['id'],safe='')+'/content', binary=True)

    def patch(self, cid, revision, fields, key, evidence):
        return self._call('/candidates/'+quote(cid,safe='')+'/missing-fields', 'PATCH',
                          {'fields': fields, 'evidence': evidence}, {'If-Match': str(revision), 'Idempotency-Key': key})

    def upload(self, cid, revision, pdf, role, key, source_refs):
        raw = pdf.read_bytes()
        return self._call('/candidates/'+quote(cid,safe='')+'/resumes', 'POST', {
            'filename': pdf.name, 'mime_type': 'application/pdf', 'role': role,
            'content_base64': base64.b64encode(raw).decode(),
            'sha256': hashlib.sha256(raw).hexdigest(), 'source_refs': source_refs},
            {'If-Match': str(revision), 'Idempotency-Key': key})

def adapter(config):
    return DemoERP(config) if config.mode == 'demo' else BridgeERP(config)
