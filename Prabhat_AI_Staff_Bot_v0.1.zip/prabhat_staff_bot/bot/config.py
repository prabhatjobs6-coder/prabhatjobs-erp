import json
import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def load_env():
    path = ROOT / '.env'
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

@dataclass
class Config:
    data: Path
    mode: str
    writes: bool
    bridge_url: str
    bridge_token: str
    api_key: str
    model: str
    budget: float
    input_price: float
    output_price: float
    ocr_lang: str
    policy: dict

    @classmethod
    def load(cls):
        load_env()
        mode = os.getenv('ERP_MODE', 'demo')
        if mode not in {'demo', 'bridge'}:
            raise ValueError('ERP_MODE must be demo or bridge')
        c = cls(Path(os.getenv('BOT_DATA_DIR', str(ROOT / 'data'))).resolve(), mode,
                os.getenv('ENABLE_WRITES', 'false').lower() == 'true',
                os.getenv('ERP_BRIDGE_URL', '').rstrip('/'), os.getenv('ERP_BRIDGE_TOKEN', ''),
                os.getenv('ANTHROPIC_API_KEY', ''), os.getenv('CLAUDE_MODEL', 'claude-haiku-5-5'),
                float(os.getenv('MONTHLY_AI_BUDGET_USD', '10')),
                float(os.getenv('INPUT_USD_PER_MTOK', '0.10')),
                float(os.getenv('OUTPUT_USD_PER_MTOK', '0.50')),
                os.getenv('OCR_LANGUAGES', 'eng'),
                json.loads((ROOT / 'policy.json').read_text()))
        if min(c.budget, c.input_price, c.output_price) < 0:
            raise ValueError('Costs must not be negative')
        if c.model != 'claude-haiku-5-5' and not all(os.getenv(x) for x in ['INPUT_USD_PER_MTOK', 'OUTPUT_USD_PER_MTOK']):
            raise ValueError('Set verified pricing when changing the model')
        c.data.mkdir(parents=True, exist_ok=True, mode=0o700)
        return c
