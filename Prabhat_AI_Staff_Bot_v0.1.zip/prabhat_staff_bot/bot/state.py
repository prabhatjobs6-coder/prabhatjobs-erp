import contextlib
import datetime as dt
import hashlib
import json
import os
import sqlite3
import time
from pathlib import Path

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

class State:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.path = self.folder / 'state.sqlite3'
        with self.db() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS jobs (
              id TEXT PRIMARY KEY, candidate TEXT, operation TEXT, role TEXT,
              state TEXT, attempts INTEGER DEFAULT 0, next_at REAL DEFAULT 0,
              payload TEXT, error TEXT, created REAL, updated REAL);
            CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, payload TEXT);
            CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, at REAL, job TEXT, action TEXT, payload TEXT);
            CREATE TABLE IF NOT EXISTS costs (id INTEGER PRIMARY KEY, month TEXT, usd REAL, status TEXT);
            CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
            ''')
        os.chmod(self.path, 0o600)

    @contextlib.contextmanager
    def db(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.row_factory = sqlite3.Row
        try:
            with con:
                yield con
        finally:
            con.close()

    @contextlib.contextmanager
    def worker_lock(self):
        # flock is released on process death; Linux/Docker is the supported runtime.
        import fcntl
        with (self.folder / 'worker.lock').open('a') as f:
            try:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError('A worker is already active') from None
            try:
                yield
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)

    def enqueue(self, key, candidate, operation, role=''):
        job = digest(key)[:24]
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO jobs(id,candidate,operation,role,state,created,updated) VALUES(?,?,?,?,?,?,?)',
                       (job, candidate, operation, role, 'queued', time.time(), time.time()))
        return job

    def get(self, job):
        with self.db() as db:
            row = db.execute('SELECT * FROM jobs WHERE id=?', (job,)).fetchone()
        if row is None:
            raise ValueError('Unknown job')
        result = dict(row)
        result['payload'] = json.loads(result['payload']) if result['payload'] else None
        return result

    def jobs(self, state=None):
        with self.db() as db:
            rows = db.execute('SELECT * FROM jobs' + (' WHERE state=?' if state else '') + ' ORDER BY created',
                              (state,) if state else ()).fetchall()
        return [dict(r) for r in rows]

    def save(self, job, state, payload=None, error=None, retry_after=0, attempt=False):
        with self.db() as db:
            db.execute('UPDATE jobs SET state=?,payload=COALESCE(?,payload),error=?,next_at=?,updated=?,attempts=attempts+? WHERE id=?',
                       (state, json.dumps(payload, ensure_ascii=False) if payload is not None else None,
                        error, time.time()+retry_after, time.time(), int(attempt), job))

    def cached(self, key):
        with self.db() as db:
            row = db.execute('SELECT payload FROM cache WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def cache(self, key, value):
        with self.db() as db:
            db.execute('INSERT OR REPLACE INTO cache VALUES(?,?)', (key, json.dumps(value, ensure_ascii=False)))

    def event(self, job, action, payload):
        with self.db() as db:
            db.execute('INSERT INTO audit(at,job,action,payload) VALUES(?,?,?,?)',
                       (time.time(), job, action, json.dumps(payload, ensure_ascii=False)))

    def kv(self, key, value=None):
        with self.db() as db:
            if value is not None:
                db.execute('INSERT OR REPLACE INTO kv VALUES(?,?)', (key, str(value)))
            row = db.execute('SELECT value FROM kv WHERE key=?', (key,)).fetchone()
        return row[0] if row else None

    def reserve(self, cost, cap):
        month = dt.datetime.now(dt.timezone.utc).strftime('%Y-%m')
        with self.db() as db:
            db.execute('BEGIN IMMEDIATE')
            spent = db.execute('SELECT COALESCE(SUM(usd),0) FROM costs WHERE month=?', (month,)).fetchone()[0]
            if spent + cost > cap:
                raise RuntimeError('Monthly AI budget reached')
            return db.execute('INSERT INTO costs(month,usd,status) VALUES(?,?,?)', (month, cost, 'reserved')).lastrowid

    def settle(self, reservation, actual):
        with self.db() as db:
            db.execute('UPDATE costs SET usd=?,status=? WHERE id=?', (actual, 'billed', reservation))

    def summary(self):
        with self.db() as db:
            counts = {r[0]: r[1] for r in db.execute('SELECT state,COUNT(*) FROM jobs GROUP BY state')}
            costs = {r[0]: round(r[1], 6) for r in db.execute('SELECT month,SUM(usd) FROM costs GROUP BY month')}
        return {'jobs': counts, 'ai_usd_including_reservations': costs}
