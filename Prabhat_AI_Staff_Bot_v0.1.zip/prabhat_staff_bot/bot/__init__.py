"""Prabhat Staff Bot: document-backed profile maintenance and resume drafts."""
__version__ = "0.1.0"
