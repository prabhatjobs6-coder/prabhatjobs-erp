import datetime as dt
import re
from .erp import empty
from .state import digest

def norm(x):
    return ' '.join(str(x).casefold().split())

def passport(x):
    return re.sub(r'[^A-Z0-9]', '', str(x).upper())

def normalize(field, value):
    if field == 'languages':
        if not isinstance(value, list) or not value or any(not isinstance(v,str) or len(v)>60 for v in value):
            raise ValueError('Invalid language list')
        return list(dict.fromkeys(value))
    if not isinstance(value, str) or not value.strip() or len(value)>1000:
        raise ValueError('Invalid field value')
    value = value.strip()
    if field in {'dob','passport_expiry'}:
        # Ambiguous numeric day/month dates deliberately require review upstream.
        for fmt in ['%Y-%m-%d', '%d %b %Y', '%d %B %Y']:
            try:
                date = dt.datetime.strptime(value,fmt).date()
                if field=='dob' and not (dt.date(1900,1,1)<=date<=dt.date.today()):
                    raise ValueError('Invalid birth date')
                return date.isoformat()
            except ValueError:
                pass
        raise ValueError('Date needs explicit unambiguous format')
    if field=='passport_no':
        value = passport(value)
        if not re.fullmatch(r'[A-Z0-9]{6,12}', value):
            raise ValueError('Invalid passport format')
    if field=='email' and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', value):
        raise ValueError('Invalid email')
    if field=='phone':
        value = re.sub(r'[\s()-]', '', value)
        if not re.fullmatch(r'\+?[0-9]{7,15}', value):
            raise ValueError('Invalid phone')
    return value

def supported(f, page):
    q = f.get('quote')
    if not isinstance(q,str) or not q.strip() or q not in page['text']:
        return False
    value = f.get('value')
    if f.get('field') == 'work_history':
        if not isinstance(value,dict) or set(value)!={'employer','role','period','duties'}:
            return False
        if not isinstance(value['duties'],list):
            return False
        vals = [value['employer'], value['role'], value['period'], *value['duties']]
    else:
        vals = value if isinstance(value,list) else [value]
    return bool(vals) and all(isinstance(v,str) and bool(v.strip()) and norm(v) in norm(q) for v in vals)

def plan(candidate, documents, policy):
    current = candidate['fields']
    facts, issues, rejected = [], [], []
    for doc in documents:
        for f in doc['facts']:
            page = next((p for p in doc['pages'] if p['page']==f.get('page')), None)
            if f.get('field') not in set(policy['allowed_fields']) | {'work_history'}:
                continue
            if not page or not supported(f, page):
                rejected.append({'doc_id':doc['doc_id'],'field':f.get('field'),'reason':'unsupported evidence'})
                continue
            try:
                v = f['value'] if f['field']=='work_history' else normalize(f['field'],f['value'])
            except ValueError as e:
                issues.append({'field':f['field'],'reason':str(e),'doc_id':doc['doc_id']})
                continue
            facts.append({**f,'value':v,'sha256':doc['sha256'],'ocr_confidence':page['confidence'],
                          'source_method':page['method']})
    existing_passport = passport(current.get('passport_no') or '')
    source_passports = {passport(f['value']) for f in facts if f['field']=='passport_no'}
    verified_bundle = bool(documents) and all(d.get('binding_verified') is True for d in documents)
    identity_ok = bool((existing_passport and source_passports=={existing_passport}) or
                       (not existing_passport and verified_bundle and len(source_passports)==1))
    if not identity_ok:
        issues.append({'field':'identity','reason':'Missing or conflicting exact passport match; bind the documents after visual review'})
    if (any(x!=existing_passport for x in source_passports) and existing_passport) or len(source_passports)>1:
        issues.append({'field':'identity_conflict','reason':'Different passport present; candidate may have mixed documents'})
    # Every source needs its own match, or an explicitly staff-verified binding from ERP.
    bound = {d['doc_id'] for d in documents if d.get('binding_verified') is True}
    bound |= {f['doc_id'] for f in facts if f['field']=='passport_no' and passport(f['value'])==existing_passport}
    proposals, histories = {}, []
    for field in policy['allowed_fields']:
        subset = [f for f in facts if f['field']==field]
        values = {}
        for f in subset:
            values.setdefault(digest(f['value']), []).append(f)
        if len(values)>1:
            issues.append({'field':field,'reason':'Documents disagree; no value selected'})
            continue
        if not values:
            continue
        support = next(iter(values.values()))
        value = support[0]['value']
        if not empty(current.get(field)):
            if norm(current[field])!=norm(value):
                # Dates from bridge must be normalized ISO YYYY-MM-DD.
                issues.append({'field':field,'reason':'Existing ERP value differs; preserved'})
            continue
        if not any(f['doc_id'] in bound for f in support):
            issues.append({'field':field,'reason':'Document identity is not verified'})
            continue
        good = [f for f in support if f['doc_id'] in bound and f['ocr_confidence']>=policy['minimum_ocr_confidence']]
        proposals[field] = {'value':value,'evidence':support,
            'auto':bool(identity_ok and field in policy['auto_fields'] and good)}
    seen = set()
    for f in facts:
        if f['field']=='work_history' and f['doc_id'] in bound and digest(f['value']) not in seen:
            seen.add(digest(f['value']))
            histories.append(f)
    if rejected:
        issues.append({'field':'extraction','reason':f'{len(rejected)} unsupported fact(s) rejected'})
    return {'candidate_id':candidate['id'],'revision':candidate['revision'], 'identity_ok':identity_ok,
            'proposals':proposals,'work_history':histories,'issues':issues,'rejected':rejected,
            'documents':[{'id':d['doc_id'],'sha256':d['sha256']} for d in documents]}
