# Prabhat AI Staff Bot - yahan se shuru karein

**Code aur demo ready hain. Bot abhi prabhatjobs.in par live nahi hai.**

Is package mein Python bot, Claude connection code, free local OCR, resume PDF generator,
review/audit system, Docker setup, optional Telegram control aur developer instructions hain.
19 local tests pass hue hain. Website ka actual backend connection abhi banana hai.

## Kaam kaise hoga

1. Candidate ke profile se original documents aur staff-selected resume roles padhega.
2. PDF/image ko local OCR se padhega; Claude configured ho to details extract karega.
3. Passport/document identity aur field ka source check karega.
4. Aapke selected missing fields ka proposal banega. Existing details aur skills preserve hongi.
5. Approved fields save honge. Jis low-risk field ko aap auto allow karenge, woh baad mein
   recurring checks mein bina baar-baar approval ke fill ho sakta hai.
6. Staff-selected occupation ka A4 resume banega. Company, experience, duties aur dates
   sirf candidate-specific evidence se aayenge. New version correct profile par upload hogi.
7. Doubtful/mixed documents review mein jayenge. Baaki candidate jobs continue rahenge.

## Aapko kya dena/configure karna hai

- Prabhatjobs ka actual source-code repository ya exported source ZIP.
- Existing server ka deployment access, ya office PC par Docker/WSL setup.
- Anthropic API key host ke private environment mein; code mein nahi.
- Aap kaunse fields auto-fill karwana chahte hain: `policy.json` mein list.
- Telegram chahiye to dedicated BotFather token aur staff numeric user IDs.

Developer/Claude Code ko pehle `docs/CLAUDE_IMPLEMENTATION_PROMPT.md` aur
`docs/ERP_BRIDGE_CONTRACT.md` dein. Isme proposed routes diye hain; woh abhi website par
installed hone ka claim nahi hai. Actual database/auth/storage dekhkar implementation karna hai.

## Kharcha kaise kam rahega

Local OCR, PDF generation aur queue par per-call AI fee nahi. Claude ko cached document dubara
extract nahi karwayenge. Existing computer use kar sakte hain; usko on rakhna padega.
Naya VPS, electricity, maintenance aur Claude usage alag cost hain.

Published Haiku 5.5 rates par example: 1,000 documents, har document 5,000 input + 1,000 output
tokens maan kar, extraction API cost approx $1. Yeh assumption hai, actual monthly quote nahi.
Verified rates aur calculation README mein hain. Default local AI budget $10/month hai;
provider account ka budget limit bhi configure karein.

## Pehle kya kholein

1. `examples/sample_resume.pdf` - synthetic sample output.
2. `README.md` - demo aur installation commands.
3. `docs/VALIDATION.md` - kya test hua aur kya live verification baaki hai.
4. `docs/ROADMAP.md` - baaki staff functions ka phased plan.

Ek hi prompt se poora ERP autonomous nahi ho jata. Yeh pehla working module hai, jise
existing ERP ke safe API connection ke saath activate karke baaki business workflows jode jayenge.
