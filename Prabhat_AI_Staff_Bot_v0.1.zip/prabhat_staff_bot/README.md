# Prabhat Staff Bot - v0.1

Prabhat Professional Consultancy Services Pvt. Ltd. | 14 October 2026

**Status: runnable, tested local prototype. Not deployed to prabhatjobs.in.**
The synthetic demo works without Claude, Telegram or ERP credentials. Live operation requires
the small ERP bridge described below and a private runtime. No real candidate records are
included in this package or modified during its creation.

## Aapke liye kya banaya hai

- Candidate documents se text aur scanned-page OCR.
- User-configured missing fields ke liye source file/page/quote ke saath proposal.
- Existing values preserve; skills/trades kabhi delete ya replace nahi hote.
- Staff-selected `resume_roles` par one-page A4 PDF, only supported experience.
- New resume version append; old original documents preserve.
- Persistent queue, content cache, exact passport matching, review queue, audit log,
  restart handling, bounded retries, and AI spending reservations.
- Optional Telegram commands; background Docker worker.

This is the first functional module, not a fully implemented replacement for every staff role.
Visa decisions, selections/rejections, finance, external messages, calls and payments are not
implemented. The expansion plan is in `docs/ROADMAP.md`.

## Cheapest practical setup

Use Python + Tesseract + SQLite + ReportLab on an existing always-on office computer or an
existing private server. Use Claude only for document interpretation. A paid workflow service
is not required. n8n can be added later if you want a visual workflow editor; it is not needed
to run this package and no n8n workflow is claimed to be implemented.

The local labeled-text parser works without an API key. General CV/experience-document parsing
requires Claude; source evidence is checked again by code. Claude currently runs once per
new/changed document when configured. Subsequent identical documents for the same candidate
reuse cached extraction. This version does not yet automatically route between model sizes.

Current official published rates checked on 14 October 2026:

| Component | Cost model |
|---|---|
| Local OCR, PDF creation, queue and code | No API charge; hardware, power, operations remain |
| Claude Haiku 5.5, prompts up to 100K tokens | $0.10 / million input tokens, $0.50 / million output tokens |
| Claude Sonnet 5.5 (optional manual model change) | $2 / million input tokens, $10 / million output tokens |
| Hosting | Existing machine/server: incremental power/usage; a new VPS quote is not included |

Illustration, not a bill prediction: 1,000 documents x (5,000 input + 1,000 output tokens)
= 5M input + 1M output = **$1.00 on the stated Haiku tier**. The 4,794 live candidate count is
not a document count. If, only as an assumption, each had three such documents, 14,382 documents
would be about **$14.38** for one extraction pass. Long documents, output/thinking tokens,
retries, taxes, changed prices, hosting and human review can increase this. Set a provider-side
spend limit as well; the included local ledger is an estimate based on configured prices.

Sources: https://www.anthropic.com/claude/haiku and
https://platform.claude.com/docs/en/models/overview . Recheck account model access and rates before enabling.

## Quick demo (Linux / WSL)

Python 3.12 recommended. Required system packages: `tesseract-ocr`, `poppler-utils`,
`fonts-dejavu-core`. Install `tesseract-ocr-hin` and `tesseract-ocr-guj` for those OCR languages.
The Docker image contains all three language packs.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m bot demo
python -m bot list
```

`data/resumes/` contains the sample PDF. `data/reviews/` contains locally viewable HTML evidence
reviews. `data/demo-candidates.json` is a disposable simulated ERP, not the website.

To test an approved **demo** write, keep `ERP_MODE=demo`, change `ENABLE_WRITES=true`, and:

```bash
python -m bot list
python -m bot review JOB_ID
python -m bot approve JOB_ID --fields city,email
```

For a resume job, inspect its PDF then run `python -m bot approve JOB_ID`. Simulated uploads
go to `data/demo-uploads/`. Each approval checks for intervening profile/document changes.
If stale, run `scan --resumes` and `run` again and review the fresh job. Unapproved fields remain
unchanged and can produce a new proposal on the next scan.

## Live prerequisites and what was verified

The connected ERP reported **4,794 candidates, 42 active vacancies, 8 employers** during this
session. Existing connector capabilities include candidate search/read/update, document
metadata listing, tasks and interviews. A document-list response was inspected: it returned
metadata rather than document bytes. No exposed document-download or resume-upload tool was
available. No private backend route, webhook, schema or deployment credential was guessed.

`ERP_BRIDGE_URL` is a NEW integration contract, **not an already-existing prabhatjobs.in URL**.
Your developer/Claude Code needs the actual ERP repository to implement it against existing
authentication, database, storage and audit services. Use `docs/CLAUDE_IMPLEMENTATION_PROMPT.md`.

1. Implement and test `docs/ERP_BRIDGE_CONTRACT.md` in the existing backend.
2. Create a dedicated scoped service token for reading documents, filling allowed empty fields,
   and appending resumes. Set bridge URL/token on the worker host, not inside source code.
3. Set an Anthropic API key with a budget. Confirm model access with your account.
4. Set `ERP_MODE=bridge`, keep `ENABLE_WRITES=false`, then run `python -m bot check`.
5. Run `scan --resumes`, then `run`. Review real source evidence and PDFs for representative
   candidate document types. Gujarati/Hindi OCR and production accuracy need this validation.
6. Configure `policy.json` with the fields YOU want. Its defaults permit proposals for common
   fields but `auto_fields` is empty, so every write initially needs review.
7. Enable writes. For recurring low-risk automatic updates, explicitly set e.g.
   `"auto_fields": ["email", "city", "state"]` after real-data validation. Identity conflicts,
   disagreeing documents and extraction problems stay in review. Resume auto-upload is a
   separate `auto_upload_resumes` switch; leave it off until output quality is accepted.
8. Start the persistent worker on your host. This chat session is not a 24/7 runtime.

Do not map arbitrary profile tags such as budget notes into resume roles. `resume_roles` must
contain occupations explicitly selected by authorized staff. Target role is not proof of
past experience. `verified_skills` and verified employment need documented/staff-verified data.

## Docker

```bash
cp .env.example .env
# Configure .env privately and edit policy.json before building.
docker compose build
docker compose run --rm worker python -m bot check
docker compose run --rm worker python -m bot demo
docker compose up -d worker
```

Data persists in Docker volume `bot_data`. Policy edits require rebuilding/recreating the
container. Do not use `docker compose down -v` unless you intend to delete its local queue,
cache, audit trail and PDFs. An office computer must stay on and connected for continuous work.

For reviews with Docker, copy a review/PDF out with `docker compose cp`, or inspect on the
private host. The package deliberately exposes no public HTTP port. A future ERP review UI
can display proposals through authenticated backend integration.

## Optional Telegram control

Create a dedicated bot in Telegram through the official BotFather account. Put its token and
your/staff numeric user IDs in `.env`. Only allowlisted private chats are accepted. The polling
service refuses to take over an existing webhook. Start it only after these are configured:

```bash
docker compose --profile telegram up -d
```

Commands implemented: `/status`, `/scan`, `/pending`, `/resume PCS-CODE Furniture Carpenter`,
`/pause`, `/resume_jobs`. The worker must run separately to process queued work. `/pause`
stops the next scheduled scan; it does not cancel an in-flight job. Telegram receives job
IDs and counts; document images, passport values and API secrets are not sent there.
Approvals happen on the private worker host after reviewing the evidence and PDF.

## Limits to know

- Profile matching requires an existing exact passport match. When the ERP passport is blank,
  every source document must be explicitly staff-bound to this candidate and contain only one
  consistent source passport before proposals can be applied. No automatic name-only match.
- DOCX evidence uses logical section 1, not Word page numbers. Gujarati/Hindi OCR can extract
  source text, but final non-Latin CV values require staff-approved English transliteration.
- Poor scans, ambiguous dates and conflicting values enter review. No invented corrections.
- Multiple-page overflow is flagged; the renderer never deletes candidate content to fit.
- Files default to 20 MB, 25 pages, 30 documents per candidate. Oversized inputs are flagged,
  never silently truncated. Document limits can be tuned after performance measurements.
- Real Claude API, live bridge, Docker image and Telegram transport have not been run here.
  See `docs/VALIDATION.md` for the actual tested scope.
- Back up the private data volume and ERP according to your retention policy. Cache and audit
  contain sensitive extracted data; this version relies on host permissions/encrypted disks.
- No malware scanner is bundled. Add your existing upload scanner in the ERP bridge before
  exposing staff-uploaded documents to a production processing service.

## Tests

```bash
python -m unittest discover -s tests -v
```
