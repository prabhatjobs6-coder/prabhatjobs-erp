import copy
import hashlib
import io
import json
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
from reportlab.pdfgen import canvas
from PIL import Image, ImageDraw, ImageFont
from pypdf import PdfReader
from bot.config import Config, ROOT
from bot.engine import Engine
from bot.erp import empty, StaleProfile
from bot.extract import pages_from_bytes, extract_document
from bot.policy import plan
from bot.state import State
from bot.telegram import authorized
from bot.net import RemoteError

class BotTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.cfg=Config(Path(self.tmp.name),'demo',False,'','','','claude-haiku-5-5',10,.1,.5,'eng',json.loads((ROOT/'policy.json').read_text()))
        self.e=Engine(self.cfg)
        self.c=self.e.erp.get('DEMO-001')
        self.doc=self.e.erp.documents('DEMO-001')[0]
        raw=self.e.erp.download('DEMO-001',self.doc)
        self.x=extract_document(raw,self.doc,self.cfg,self.e.state)
        self.x['binding_verified']=True

    def tearDown(self): self.tmp.cleanup()

    def test_only_missing_fields_and_skills_preserved(self):
        self.e.scan(); self.e.run()
        job=self.e.state.jobs('review')[0]
        p=self.e.state.get(job['id'])['payload']['plan']
        self.assertNotIn('name',p['proposals']); self.assertNotIn('phone',p['proposals'])
        self.cfg.writes=True
        self.e.apply(job['id'],['city','email'])
        after=self.e.erp.get('DEMO-001')
        self.assertEqual(after['skills'],self.c['skills'])
        self.assertEqual(after['fields']['name'],self.c['fields']['name'])
        self.assertEqual(after['fields']['city'],'Porbandar')
        self.assertEqual(after['fields']['state'],'')

    def test_preview_never_writes(self):
        self.e.scan(resumes=True); self.e.run()
        self.assertEqual(self.e.erp.get('DEMO-001'),self.c)
        with self.assertRaises(RuntimeError): self.e.apply(self.e.state.jobs('review')[0]['id'],['city'])

    def test_ambiguous_date_rejected(self):
        x=copy.deepcopy(self.x)
        for p in x['pages']: p['text']=p['text'].replace('1990-06-15','06/07/1990')
        for f in x['facts']:
            if f['field']=='dob': f['value']='06/07/1990'; f['quote']='Date of Birth: 06/07/1990'
        p=plan(self.c,[x],self.cfg.policy)
        self.assertNotIn('dob',p['proposals'])
        self.assertTrue(any(i['field']=='dob' for i in p['issues']))

    def test_conflicting_passport_blocks_identity(self):
        x=copy.deepcopy(self.x)
        x['pages'][0]['text']+='\nPassport Number: OTHER123'
        x['facts'].append({'field':'passport_no','value':'OTHER123','doc_id':self.doc['id'],'page':1,'quote':'Passport Number: OTHER123','extractor':'claude'})
        p=plan(self.c,[x],self.cfg.policy)
        self.assertFalse(p['identity_ok'])
        self.assertTrue(any(i['field']=='identity_conflict' for i in p['issues']))

    def test_fake_claude_evidence_rejected(self):
        x=copy.deepcopy(self.x)
        x['facts'].append({'field':'education','value':'PhD','doc_id':self.doc['id'],'page':1,'quote':'Email: arjun.demo@example.invalid','extractor':'claude'})
        p=plan(self.c,[x],self.cfg.policy)
        self.assertEqual(len(p['rejected']),1)
        self.assertEqual(p['proposals']['education']['value'],'Secondary School Certificate')

    def test_conflicting_existing_value_preserved(self):
        c=copy.deepcopy(self.c); c['fields']['city']='Jamnagar'
        p=plan(c,[self.x],self.cfg.policy)
        self.assertNotIn('city',p['proposals'])
        self.assertTrue(any(i['field']=='city' for i in p['issues']))

    def test_stale_profile_does_not_overwrite(self):
        self.e.scan(); self.e.run(); job=self.e.state.jobs('review')[0]['id']
        self.e.erp.patch('DEMO-001','1',{'city':'Staff edit'},'staff',{})
        self.cfg.writes=True
        with self.assertRaises(StaleProfile): self.e.apply(job,['city'])
        self.assertEqual(self.e.erp.get('DEMO-001')['fields']['city'],'Staff edit')

    def test_resume_pdf_and_duplicate_protection(self):
        self.e.enqueue_candidate(self.c,[self.doc],role='Furniture Carpenter')
        self.e.run(); job=self.e.state.jobs('review')[0]['id']
        data=self.e.state.get(job)['payload']; pdf=Path(data['pdf'])
        reader=PdfReader(pdf)
        self.assertEqual(len(reader.pages),1)
        self.assertAlmostEqual(float(reader.pages[0].mediabox.width),595.2756,places=2)
        self.assertIn('Furniture Carpenter',reader.pages[0].extract_text())
        self.assertNotIn('DEMO0001',reader.pages[0].extract_text())
        self.cfg.writes=True; self.e.apply(job,[]); self.e.apply(job,[])
        self.e.enqueue_candidate(self.c,[self.doc],role='Furniture Carpenter',force=True)
        self.e.run(); job2=self.e.state.jobs('review')[0]['id']
        self.e.apply(job2,[])
        self.assertEqual(len(self.e.erp.get('DEMO-001')['resumes']),1)

    def test_cache_no_repeat_extraction(self):
        first=self.x
        result=extract_document(self.e.erp.download('DEMO-001',self.doc),self.doc,self.cfg,self.e.state)
        self.assertEqual(first['facts'],result['facts'])
        self.e.scan(); self.e.scan()
        self.assertEqual(len(self.e.state.jobs()),1)

    def test_pdf_text_extraction(self):
        raw=io.BytesIO(); c=canvas.Canvas(raw)
        c.drawString(50,750,'Passport Number: DEMO0001')
        c.drawString(50,720,'Full Name: Arjun Demo Patel - This is a synthetic document.'); c.save()
        pages=pages_from_bytes(raw.getvalue(),'sample.pdf',self.cfg.policy,'eng')
        self.assertIn('DEMO0001',pages[0]['text'])

    def test_real_local_image_ocr(self):
        image=Image.new('RGB',(1800,350),'white'); d=ImageDraw.Draw(image)
        font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',48)
        d.text((50,80),'Full Name: Arjun Demo Patel',font=font,fill='black')
        raw=io.BytesIO(); image.save(raw,format='PNG')
        pages=pages_from_bytes(raw.getvalue(),'scan.png',self.cfg.policy,'eng')
        self.assertIn('Arjun Demo Patel',pages[0]['text'])
        self.assertEqual(pages[0]['method'],'ocr')

    def test_empty_does_not_mean_zero_false(self):
        self.assertFalse(empty(0)); self.assertFalse(empty(False)); self.assertTrue(empty(None))

    def test_budget_reservation_blocks_spend(self):
        self.e.state.reserve(.9,1)
        with self.assertRaises(RuntimeError): self.e.state.reserve(.2,1)

    def test_telegram_access_private_and_allowlisted(self):
        self.assertTrue(authorized({'chat':{'type':'private'},'from':{'id':1}},{'1'}))
        self.assertFalse(authorized({'chat':{'type':'group'},'from':{'id':1}},{'1'}))
        self.assertFalse(authorized({'chat':{'type':'private'},'from':{'id':2}},{'1'}))

    def test_no_unselected_role(self):
        with self.assertRaises(ValueError): self.e.enqueue_candidate(self.c,[self.doc],role='Welder')

    def test_write_requires_field_scope(self):
        self.e.scan();self.e.run(); self.cfg.writes=True
        job=self.e.state.jobs('review')[0]['id']
        with self.assertRaises(ValueError): self.e.apply(job,['skills'])

    def test_missing_passport_requires_staff_bound_bundle(self):
        c=copy.deepcopy(self.c); c['fields']['passport_no']=''
        p=plan(c,[self.x],self.cfg.policy)
        self.assertTrue(p['identity_ok'])
        self.assertEqual(p['proposals']['passport_no']['value'],'DEMO0001')
        x=copy.deepcopy(self.x); x['binding_verified']=False
        self.assertFalse(plan(c,[x],self.cfg.policy)['identity_ok'])

    def test_automatic_writes_only_selected_fields(self):
        self.cfg.policy['auto_fields']=['city']; self.cfg.writes=True
        self.e.scan(); self.e.run()
        fields=self.e.erp.get('DEMO-001')['fields']
        self.assertEqual(fields['city'],'Porbandar'); self.assertEqual(fields['email'],'')

    def test_retry_queue_survives_restart(self):
        self.e.scan()
        with patch.object(self.e.erp,'download',side_effect=RemoteError(429)):
            self.e.run()
        jobs=self.e.state.jobs('queued')
        self.assertEqual(len(jobs),1); self.assertEqual(jobs[0]['attempts'],1)
        self.e.state.save(jobs[0]['id'],'queued')
        restarted=Engine(self.cfg); restarted.run()
        self.assertEqual(restarted.state.get(jobs[0]['id'])['state'],'review')

if __name__=='__main__': unittest.main()
